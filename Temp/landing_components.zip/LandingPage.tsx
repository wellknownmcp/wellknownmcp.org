import { PageHeader } from '@/components/landing/PageHeader'
import { DownloadFeeds } from '@/components/landing/DownloadFeeds'
import { TestimonyCarousel } from '@/components/landing/TestimonyCarousel'
import { WhatYouCanDeclare } from '@/components/landing/WhatYouCanDeclare'
import { ToolsGrid } from '@/components/landing/ToolsGrid'
import { FAQList } from '@/components/landing/FAQList'
import { MissionBadges } from '@/components/landing/MissionBadges'
import { NewsSection } from '@/components/landing/NewsSection'
import { InjectHooks } from '@/components/landing/InjectHooks'
import { SiteBadge } from '@/components/landing/SiteBadge'
import { TryAgent } from '@/components/landing/TryAgent'

export default function LandingPage() {
  return (
    <main className="pb-24">
      <PageHeader />
      <DownloadFeeds />
      <TestimonyCarousel />
      <TryAgent />
      <WhatYouCanDeclare />
      <ToolsGrid />
      <FAQList />
      <MissionBadges />
      <NewsSection />
      <InjectHooks />
      <SiteBadge />
    </main>
  )
}