import Link from 'next/link'
import { Wand2, FileText, PanelRightOpen, FileJson } from 'lucide-react'

const tools = [
  {
    title: 'Prompt Engineering Capsule',
    description: 'Explain structured prompts to agents.',
    href: '/tools/prompt',
    icon: Wand2
  },
  {
    title: 'Session Feed',
    description: 'Capture and replay agent interaction history.',
    href: '/tools/session-feed',
    icon: FileText
  },
  {
    title: 'Export Button',
    description: 'Let users export any page as a structured LLMFeed.',
    href: '/tools/export-button',
    icon: PanelRightOpen
  },
  {
    title: 'MCP Feed Explained',
    description: 'Understand what an agent sees in /mcp.llmfeed.json.',
    href: '/tools/mcp-explained',
    icon: FileJson
  }
]

export function ToolsGrid() {
  return (
    <div className="max-w-5xl mx-auto py-12">
      <h2 className="text-xl font-semibold text-center">🧰 Tools and Capsules</h2>
      <div className="grid sm:grid-cols-2 gap-6 mt-6">
        {tools.map(({ title, description, href, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className="border rounded-xl p-4 flex flex-col gap-2 hover:bg-zinc-50 dark:hover:bg-zinc-800"
          >
            <div className="flex items-center gap-2">
              <Icon className="w-5 h-5 text-purple-600" />
              <span className="font-medium text-zinc-900 dark:text-zinc-100">{title}</span>
            </div>
            <p className="text-sm text-muted-foreground">{description}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}