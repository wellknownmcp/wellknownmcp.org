# How to use

Run `node generate-rss.js` to regenerate RSS feeds.
Place RSS feeds in `/public/news/lang/rss.xml`.
Declare RSS feeds in <head> like:
<link rel="alternate" type="application/rss+xml" title="News EN" href="/news/en/rss.xml">