'use client'

import SeoHead from '@/components/SeoHead'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import matter from 'gray-matter'
import Image from 'next/image'
import { ExportToLLMButton } from '@/components/ExportToLLMButton'

interface ArticleMeta {
  lang: string
  slug: string
  title: string
  description: string
  tags: string[]
  date: string
}

export default function HomePage() {
  const [articles, setArticles] = useState<ArticleMeta[]>([])

  useEffect(() => {
    async function loadRecentNews() {
      const langs = ['en']
      const res = await fetch('/news/index.json')
      const allSlugs = await res.json()

      const results: ArticleMeta[] = []

      for (const lang of langs) {
        const slugs: string[] = Array.isArray(allSlugs[lang])
          ? allSlugs[lang]
          : []
        for (const slug of slugs) {
          try {
            const res = await fetch(`/news/${lang}/${slug}.md`)
            if (!res.ok) continue
            const text = await res.text()
            const { data } = matter(text)
            results.push({
              lang,
              slug,
              title: data.title || slug,
              description: data.description || '',
              tags: data.tags || [],
              date: data.date || 'unknown',
            })
          } catch {
            continue
          }
        }
      }

      results.sort(
        (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
      )
      setArticles(results.slice(0, 3))
    }
    loadRecentNews()
  }, [])

  return (
    <>
      <SeoHead
        title="WellKnownMCP.org — Standard for AI-readable trust"
        description="Explore the MCP standard and certify your feeds. Empower agents, structure context, and build the trusted web for AI."
        ogImage="/og/home.png"
        canonicalUrl="https://wellknownmcp.org"
        llmIntent="discover-mcp-standard"
        llmTopic="mcp"
        llmIndexUrl="https://wellknownmcp.org/.well-known/llm-index.llmfeed.json"
        llmlang="en"
        keywords={['mcp', 'llmfeed', 'ai agents', 'trust', 'specification']}
      />

      <main className="w-full px-4 py-16 space-y-24 bg-white dark:bg-black">
        <section className="text-center py-20 bg-gradient-to-b from-gray-100 to-white dark:from-zinc-900 dark:to-black">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            The Web for Agents Begins Here.
          </h1>
          <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 mb-8">
            LLM-ready standards, feeds and trust infrastructure.
          </p>
          <p className="mt-6 text-sm text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            For the first time, agents can browse, interpret, and trust web
            content — thanks to MCP. This isn't an extension of the human web.
            It's the foundation of a new one.
          </p>

          <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
            <Link
              href="/spec"
              className="bg-black text-white dark:bg-white dark:text-black px-6 py-3 rounded-full font-medium shadow hover:opacity-80 transition no-underline"
            >
              Explore the Spec
            </Link>
            <Link
              href="/en/news/begin"
              className="text-black dark:text-white border border-black dark:border-white px-6 py-3 rounded-full font-medium hover:bg-gray-100 dark:hover:bg-zinc-800 transition no-underline"
            >
              Where to Begin
            </Link>
            <Link
              href="/llmfeedhub"
              className="bg-black text-white dark:bg-white dark:text-black px-6 py-3 rounded-full font-medium shadow hover:opacity-80 transition no-underline"
            >
              LLMFeed Hub
            </Link>
          </div>
          <p className="mt-4 text-sm text-gray-600 dark:text-gray-400 text-center">
            👉 Want to test a real example? Visit{' '}
            <Link href="/llmfeedhub/kungfu" className="underline">
              /llmfeedhub/kungfu
            </Link>{' '}
            to try now.
          </p>
        </section>
        <section className="max-w-5xl mx-auto mt-20 px-4 space-y-6">
          <h2 className="text-xl font-bold text-center">
            ⚡ Agent-Powered Creation Tools
          </h2>
          <p className="text-sm text-muted-foreground text-center">
            Create and reuse content or context for agents. These tools make LLM
            outputs portable, auditable, and shareable.
          </p>
          <div className="grid gap-6 md:grid-cols-2 mt-8">
            <div className="border rounded-lg p-6 bg-muted/20">
              <h3 className="text-lg font-semibold mb-2">
                ✍️ Structure & Sign Your Prompt
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                Create a portable, agent-compatible prompt you can sign, export
                or publish. Perfect for prompt engineers & LLM builders.
              </p>
              <a
                href="/tools/prompt"
                className="text-sm font-medium text-violet-600 hover:underline"
              >
                Open Prompt Tool →
              </a>
            </div>
            <div className="border rounded-lg p-6 bg-muted/20">
              <h3 className="text-lg font-semibold mb-2">
                🧠 Export Your Session
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                Save your current LLM context as a structured, resumable
                capsule. Compatible with any agent or chat platform.
              </p>
              <a
                href="/tools/session-export"
                className="text-sm font-medium text-violet-600 hover:underline"
              >
                Open Session Export →
              </a>
            </div>
          </div>
        </section>
        <section className="text-center max-w-4xl mx-auto mt-12 px-4 space-y-6">
          <h2 className="text-xl font-bold">📖 Understand MCP Concepts</h2>
          <p className="text-sm text-muted-foreground">
            Learn how agents interpret feeds, triggers, and declared intentions.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/tools/prompts-explained" className="underline">
              Prompt Intents
            </Link>
            <Link href="/tools/well-known" className="underline">
              Well-Known Folder
            </Link>
            <Link href="/tools/export-button" className="underline">
              Export Button
            </Link>
            <Link href="/tools/llm-index" className="underline">
              LLM Index
            </Link>
          </div>
        </section>
        <section className="max-w-3xl mx-auto mt-16 p-6 rounded-2xl border border-gray-300 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-center space-y-4 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            🎉 Featured: Export to LLM Button
          </h2>
          <p className="text-base text-gray-700 dark:text-gray-300">
            Easily add a MCP Export button to your project. Agents and LLMs can
            instantly fetch your structured context.
          </p>
          <div className="flex justify-center mt-4">
            <ExportToLLMButton context="static" staticPath="about" highlight />
          </div>
          <Link
            href="/tools/export-button"
            className="inline-block mt-4 bg-black text-white dark:bg-white dark:text-black px-5 py-2 rounded-full font-medium hover:opacity-80 transition no-underline"
          >
            See how it works →
          </Link>
        </section>
        {/* 2. Mission & Vision */}
        <section className="text-center max-w-4xl mx-auto px-4">
          <div className="grid sm:grid-cols-3 gap-6 text-left sm:text-center">
            <div>
              <h3 className="text-3xl mb-2">📜</h3>
              <p>A universal format to describe knowledge</p>
            </div>
            <div>
              <h3 className="text-3xl mb-2">🛡️</h3>
              <p>Cryptographically verifiable trust</p>
            </div>
            <div>
              <h3 className="text-3xl mb-2">⚙️</h3>
              <p>Interoperable across LLMs & platforms</p>
            </div>
          </div>
          <p className="mt-8 italic underline decoration-dotted">
            A new layer of meaning, made for machines.
          </p>
        </section>

        <section className="max-w-4xl mx-auto text-left px-4">
          <h2 className="text-2xl font-bold mb-4">Latest News</h2>
          <ul className="space-y-4">
            {articles.map((article) => (
              <li key={article.slug}>
                <Link
                  href={`/news/${article.lang}/${article.slug}`}
                  className="text-lg font-medium text-black dark:text-white no-underline hover:underline"
                >
                  {article.title}
                </Link>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {article.description}
                </p>
              </li>
            ))}
          </ul>
          <div className="text-center mt-6">
            <Link
              href="/news"
              className="text-sm underline text-gray-700 dark:text-gray-300"
            >
              Read all news →
            </Link>
          </div>
        </section>

        <section className="max-w-3xl mx-auto mt-16 p-6 rounded-2xl border border-gray-300 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-center space-y-4 shadow-md">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            🏅 Badges & Certification
          </h2>
          <p className="text-base text-gray-700 dark:text-gray-300">
            Reward your project or dataset with MCP Certified, LLMFeed Certified
            and Export Certified badges.
          </p>
          <div className="flex justify-center gap-6 items-center mt-4">
            <img
              src="/assets/badges/mcp_certified.svg"
              alt="MCP Certified"
              className="h-6 w-auto"
            />
            <img
              src="/assets/badges/llmfeed_certified.svg"
              alt="LLMFeed Certified"
              className="h-6 w-auto"
            />
            <img
              src="/assets/badges/export_certified.svg"
              alt="Export Certified"
              className="h-6 w-auto"
            />
          </div>
        </section>

        <p className="text-center mt-12 text-lg italic text-gray-500 dark:text-gray-400">
          The web is no longer just for humans. It’s for agents, too.
        </p>

        <section className="max-w-4xl mx-auto mt-20 px-4 py-8 rounded-xl border border-gray-300 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-center space-y-4 shadow-sm">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            🚀 Quickstart for Agents
          </h2>
          <p className="text-base text-muted-foreground">
            Want your LLM agent to instantly understand this site?
            <br />
            Give it these two feeds:
          </p>
          <div className="flex justify-center items-center gap-6 mt-4 flex-wrap">
            <ExportToLLMButton
              context="dynamic"
              dynamicId="compiled-site"
            />
            <ExportToLLMButton
              context="static"
              staticPath="./well-known/exports/compiled-site.llmfeed.json"
            />
            <ExportToLLMButton
              context="static"
              staticPath="exports/spec/spec.llmfeed.json"
            />
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
            This is the fastest way for an agent to become context-aware.
            <br className="hidden sm:inline" />
            <Link href="/tools/prompt" className="underline">
              Or inject a prompt instead →
            </Link>
          </p>
        </section>
        <div className="text-sm text-muted-foreground text-center mt-10">
          Building your own agent?
          <Link href="/tools/prompt" className="ml-1 underline">
            Inject our behavior prompts →
          </Link>
        </div>

        <div className="text-sm text-muted-foreground text-center mt-4">
          Want to make your feed trusted?
          <Link href="https://llmca.org" className="ml-1 underline">
            Request certification at LLMCA →
          </Link>
        </div>

        <div className="text-sm text-muted-foreground text-center mt-4 italic">
          🤖 Curious about how agents read websites?
          <Link href="/tools/prompt" className="underline">
            Ask your favorite LLM about MCP →
          </Link>
        </div>
      </main>
    </>
  )
}
